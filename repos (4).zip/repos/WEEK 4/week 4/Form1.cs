﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "choose a file for reading";
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files(*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.ShowDialog();
            if(openFileDialog1.ShowDialog()==DialogResult.OK)
            {
                var filepath = openFileDialog1.FileName;
                var filestream = openFileDialog1.OpenFile();
                using (StreamReader reader = new StreamReader(filestream))
                {
                    var filecontent = reader.ReadToEnd();
                    textBox1.Text = (filecontent);
                    MessageBox.Show(filecontent);

                }
            }
        }
    }
}
