﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _5._1_assigment
{
    public partial class Form2 : Form
    {
        double[] nums = new double[3];

        string textfile = "palestine.txt";// The name of the  text file here 


        public Form2(string tr)
        {
            InitializeComponent();
            textBox1.Text = tr;

        }







        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1(textBox1.Text);
            f1.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            decimal[] nums = new decimal[4];
            decimal sum = 0;
            // check if the input values in textbox5 and textbox and textbox 7 and textbox 8 can be parsed as decimals 
            if (decimal.TryParse(textBox2.Text, out nums[0]) &&
              decimal.TryParse(textBox3.Text, out nums[1]) &&
               decimal.TryParse(textBox4.Text, out nums[2]) &&
                  decimal.TryParse(textBox5.Text, out nums[3]))
            {
                Array.Sort(nums);


                // calculate the sum of the inputs values 
                for (int i = 0; i < nums.Length; i++)
                {
                    sum += nums[i];
                }

                decimal average = sum / 4;



                textBox6.Text = average.ToString("F2");
                string filepath = "s ";
                using (StreamWriter writer = new StreamWriter(filepath))
                {
                    writer.WriteLine("Average : " + average.ToString("F2"));
                }

                foreach (Control x in this.Controls)

                    if (x is Label)
                    {
                        // set the background color of the label to darkred

                        x.BackColor = Color.DarkRed;
                        // set the text color (forecolor) of the label to khai
                        x.ForeColor = Color.Khaki;


                    }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (double.TryParse(textBox7.Text, out nums[0]) &&
    double.TryParse(textBox8.Text, out nums[1]) &&
    double.TryParse(textBox9.Text, out nums[2]))

            {
                // sort the inputs from the smallest to the biggest
                Array.Sort(nums);
                // calculate the sum of the sorted numbers 
                double sum = nums[0] + nums[1] + nums[2];
                // display sum in textbox4
                textBox10.Text = sum.ToString();
                textBox10.ForeColor = (sum > 200) ? Color.DarkViolet : SystemColors.ControlText;

                textBox7.Text = nums[0].ToString();
                textBox8.Text = nums[1].ToString();
                textBox9.Text = nums[2].ToString();
                {


                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {



        }

        private void button4_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    if (File.Exists(textfile))
                    {
                        string fileContent = File.ReadAllText(textfile);
                        MessageBox.Show(fileContent, "file content");
                    }


                    else
                    {

                        MessageBox.Show("File does not exist .", "File Read");

                    }

                }
                catch (Exception ex)

                {
                    MessageBox.Show("an error occured:" + ex.Message, "error");
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            // Append text from textbox 13 to the end of the "HEALTHY.txt" file.

            try
            {
                File.AppendAllText(textfile, textBox11.Text + Environment.NewLine);
                MessageBox.Show("text appended to the file.", "file append");
            }
            catch (Exception ex)
            {
                MessageBox.Show("an error occured:" + ex.Message, "error");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "choose a file for reading";
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.Filter = "txt files(*.txt)|*.txt|All files(*.*)|*.*";
            openFileDialog1.FilterIndex = 1;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var filepath = openFileDialog1.FileName;

                {
                    if (File.Exists(filepath))

                    {
                        try
                        {
                            using (StreamReader reader = new StreamReader(filepath))
                            {



                                var filecontent = reader.ReadToEnd();
                                textBox11.Text = (filecontent);
                                MessageBox.Show(filecontent);

                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(" an error occured while reading the file:" + ex.Message, "error");


                        }
                    }

                }
            }
        }









        private void button7_Click(object sender, EventArgs e)
        {

            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0)
                MessageBox.Show("yougurt100,Eggs78,Grained bread75, Avocado240");
            else if (listBox1.SelectedIndex == 1)
                MessageBox.Show("Tuna 203, Mini sweet Peppers35, Hummus130, Apples95 ");
            else
            {
                MessageBox.Show(" poultry296, salmon 824,potatoes164,brown rice216");
                listBox1.BackColor = Color.DarkOrange;
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

            textBox5.BackColor = Color.Gold;
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

            textBox2.BackColor = Color.YellowGreen;
        }

        private void textBox3_TextChanged_1(object sender, EventArgs e)
        {

            textBox3.BackColor = Color.DeepPink;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            textBox4.BackColor = Color.Purple;
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

        

        
    



