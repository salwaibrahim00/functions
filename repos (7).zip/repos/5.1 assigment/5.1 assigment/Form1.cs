﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _5._1_assigment
{
    public partial class Form1 : Form
    {
        double[] nums = new double[3];



        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        // check if the input values textbox1 , textbox2 and textbox 3 with the sorted values
        {
            if (double.TryParse(textBox1.Text, out nums[0]) &&
    double.TryParse(textBox2.Text, out nums[1]) &&
    double.TryParse(textBox3.Text, out nums[2]))

            {
                // sort the inputs from the smallest to the biggest
                Array.Sort(nums);
                // calculate the sum of the sorted numbers 
                double sum = nums[0] + nums[1] + nums[2];
                // display sum in textbox4
                textBox4.Text = sum.ToString();
                textBox4.ForeColor = (sum > 200) ? Color.DarkViolet : SystemColors.ControlText;

                textBox1.Text = nums[0].ToString();
                textBox2.Text = nums[1].ToString();
                textBox3.Text = nums[2].ToString();

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            textBox1.BackColor = Color.Blue;// change the background color blue
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.BackColor = Color.DarkGreen;// change the backgroung color to darkgreen
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            textBox3.BackColor = Color.Orange;// change the backgroung color to orange

        }

        private void button2_Click(object sender, EventArgs e)
        {
            decimal[] nums = new decimal[4];
            decimal sum = 0;
            // check if the input values in textbox5 and textbox and textbox 7 and textbox 8 can be parsed as decimals 
            if (decimal.TryParse(textBox5.Text, out nums[0]) &&
              decimal.TryParse(textBox6.Text, out nums[1]) &&
               decimal.TryParse(textBox7.Text, out nums[2]) &&
                  decimal.TryParse(textBox8.Text, out nums[3]))
            {
                sum = 0;
                // calculate the sum of the inputs values 
                for (int i = 0; i < nums.Length; i++)
                {
                    sum += nums[i];

                }
                // calculate the results by dividing  the sum by the numbers of values (4)
                decimal average = sum / 4;
                //display the sum in textbox 9 and thr average in textbox 10
                textBox9.Text = sum.ToString();
                textBox10.Text = average.ToString("F2");
                foreach (Control x in this.Controls)
                {
                    if (x is Label)
                    {
                        // set the background color of the label to darkred
                        
                        x.BackColor = Color.DarkRed;
                        // set the text color (forecolor) of the label to khai
                        x.ForeColor = Color.Khaki;

                      

                        
                        
                        
                    }
                }
            }




        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

    }
}

