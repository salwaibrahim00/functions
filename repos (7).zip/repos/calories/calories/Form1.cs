﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace calories
{
    public partial class Form1 : Form
    {

        double[] nums = new double[3];


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out nums[0]) &&
                double.TryParse(textBox2.Text, out nums[1]) &&
                double.TryParse(textBox3.Text, out nums[2]))


                Array.Sort(nums);
            double sum = nums[0] + nums[1] + nums[2];

            textBox4.Text = sum.ToString();
            textBox4.ForeColor = (sum > 200) ? Color.DarkViolet : SystemColors.ControlText;

            (textBox1.Text) = nums[0].ToString();
            (textBox2.Text) = nums[1].ToString();
            (textBox3.Text) = nums[2].ToString();

        }
    }
}
            
          

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

            textBox1.BackColor = Color.Blue;// change the background color blue
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

            textBox2.BackColor = Color.DarkGreen;// change the backgroung color to darkgreen

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox3.BackColor = Color.Orange;// change the backgroung color to orange
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.ForeColor = Color.YellowGreen;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
        }
    }
}

            
                  
                
                     
                
