﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace @class
{
    public partial class Form1 : Form
    {
        class patient
        {
            private string fname;
            private string lname;
            public patient(string fn, string ln)
            {
                if (fn.Length == 0)
                {
                    MessageBox.Show("invalid fname,name set to dana ");
                    fname = "dana";

                }
                else
                    fname=fn;
                if (ln.Length == 0)
                {
                    MessageBox.Show(" invalid lname , name, name set to sami");
                    lname = "sami";
                }
                else
                    lname = ln;
            }
            
            public string Fname
            {
                get { return fname; }
                set { fname = value; }
            }
            public void display()
            {
                MessageBox.Show("patient name =" + fname + "" + lname);
            }


        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)

        {
            patient el = new patient(textBox1.Text, textBox2.Text);
            el.display();
        }
    }
}
