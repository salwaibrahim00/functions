﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static final_project.Form1;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace final_project
{
    public partial class Form1 : Form
    {
        int age;
        string gender;
        double weightKg, heightM;
        public class Customer
        {
            private string fname;
            private string lname;
            public Customer(string fn, string ln)
            {
                if (fn.Length == 0)
                {
                    MessageBox.Show("invalid fname, nameser to Dana");
                    fname = "Dana";
                }
                else
                    fname = fn;
                if (ln.Length == 0)
                {
                    MessageBox.Show("invalid lname , name , name set to Sami");
                    lname = "Sami";
                }
                else
                    lname = ln;
            }
            public string Fname
            {
                get { return fname; }
                set { fname = value; }

            }
            public void display()
            {
                MessageBox.Show(" customer name =" + fname + "" + lname);

            }
        }

        public class BMICalculator
        {
            public double CalculateBMI(double height, double weight)

            {
                if (height == 0)
                {
                    MessageBox.Show("Invalid height; BMI cannot be calculated.");
                    return 0;
                }
                return weight / (height * height);
            }
            public string GetBMICategory(double bmi)
            {
                if (bmi < 18.5)
                    return "underweight";
                else if (bmi < 24.9)
                    return "normal weight";
                else if (bmi < 29.9)
                    return "overweight";
                else
                    return "obese";

            }
            public void DisplayBMIInfo(double height, double weight)
            {
                double bmi = CalculateBMI(height, weight);
                string category = GetBMICategory(bmi);
                MessageBox.Show($"BMI:{bmi:F2}\nCategory:{category}");
            }

        }
        
        public class ChildrenBMICalculator : BMICalculator
        {
            public double CalculateBMI(double height, double weight, int age, string gender)
            {
                if (height <= 0 || weight <= 0)
                {

                    MessageBox.Show(" invalid height or weight; BMI  for children cannot be  calculated");
                    return 0;

                }
                return weight / (height * height);
            }
            public string GetBMICategoryForChild(double bmi)
            {
                if (bmi < 12)
                    return "underweight";
                else if (bmi >= 12 && bmi < 17)
                    return "normal weight";
                else if (bmi >= 17 && bmi < 20)
                    return "overweight";
                else
                    return "obese";
            }


            public void DisplayBMIInfoForChild(double height, double weight, int age, string gender)

            {
                double bmi = CalculateBMI(height, weight);
                string category = GetBMICategoryForChild(bmi);
                MessageBox.Show($"BMI:{bmi:F2}\nCategory:{category}\nAge:{age}\nGender: {gender}");
            }
        }

        int GetChildAge()
        {
            if (int.TryParse(textBox8.Text, out int age))
            {
                return age;
            }
            else
            {
                MessageBox.Show("please enter a valid age");
                return 0;
            }
        }
        string GetChildGender()
        {
            if (radioButton1.Checked)
            {
                return " male";

            }
            else if (radioButton2.Checked)
            {
                return " female";
            }
            MessageBox.Show("please select the childs gender.");
            return string.Empty;






        }





        public Form1()
        {
            InitializeComponent();
        }




        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string firstName = textBox1.Text;
            String lastname = textBox2.Text;
            Customer customer = new Customer(firstName, lastname);
            customer.display();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string firstName = textBox1.Text;
            String lastName = textBox2.Text;
            Customer customer = new Customer(firstName, lastName);
            customer.display();
            double height, weight;
            if (double.TryParse(textBox3.Text, out height) && double.TryParse(textBox4.Text, out weight))

            {
                BMICalculator bMICalculator = new BMICalculator();
                bMICalculator.DisplayBMIInfo(height, weight);
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_MouseEnter(object sender, EventArgs e)
        {
            label5.Text = " This a BMI (Body Mass Index )for adults  calculates the amount of fat in your body ";
            label5.Location = new Point(panel1.Location.X, panel1.Location.Y + panel1.Height + 5);
        }

        private void panel1_MouseLeave(object sender, EventArgs e)
        {
            label5.Visible = false;
        }

        private void panel2_MouseEnter(object sender, EventArgs e)
        {
            label9.Text = " This a BMI (Body Mass Index )for children  calculates the amount of fat in your body ";
            label9.Location = new Point(panel2.Location.X, panel2.Location.Y + panel2.Height + 5);
        }

        private void panel2_MouseLeave(object sender, EventArgs e)
        {
            label9.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
         
           
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
           
            
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            // convert pounds to kilograms and show the results in a messagebox five times
            if (double.TryParse(textBox10.Text, out double pounds))

                for (int i = 0; i <= 5; i++)// use < instead of<= to loop 5 times
                {
                    double kilograms = pounds * 0.45359237;
                    // Display the results in a messagebox with additional information
                    MessageBox.Show($"i={i}pounds= {pounds},kilograms={kilograms:F2}", "answer");

                }
        }

        private void button6_Click(object sender, EventArgs e)
        {


            if (double.TryParse(textBox9.Text, out double inches))

                for (int i = 0; i <= 5; i++)// use < instead of<= to loop 2 times
                {
                    double meters = inches * 0.0254;
                    // Display the results in a messagebox with additional information
                    MessageBox.Show($" Iteration :{i + 1} \nInches:{inches:F2}\nMeters:{meters:F2}", "Conversion Result");
                    if (meters > 100)
                    {
                        textBox9.BackColor = Color.AliceBlue;
                    }
                }
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel3_MouseEnter(object sender, EventArgs e)
        {

            label10.Text = "  Convertor from pounds to kilograms and from inches to meter";
            label10.Location = new Point(panel3.Location.X, panel3.Location.Y + panel3.Height + 5);
        }

        private void panel3_MouseLeave(object sender, EventArgs e)
        {
            label10.Visible = false;
        }

        private void button4_Click_1(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string firstName = textBox1.Text;
            string lastname = textBox2.Text;
            Customer customer = new Customer(firstName, lastname);
            customer.display();
            double height, weight;
            if (double.TryParse(textBox6.Text, out height) && double.TryParse(textBox7.Text, out weight))
            {
                ChildrenBMICalculator bmiCalclator = new ChildrenBMICalculator();
                int age = GetChildAge();

                string gender = GetChildGender();

                ChildrenBMICalculator bmiCalculator = new ChildrenBMICalculator();
                bmiCalculator.DisplayBMIInfoForChild(height, weight, age, gender);

            }
        }
    }
}




