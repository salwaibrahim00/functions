﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        class shape
        {
            public double width;
            public double height;
            public void showdim()
                {

                MessageBox.Show("width and height are" + width + " and"+ height, " dimensions");
            }
        }
        class trinagle: shape
        {
            public string style;
                public double Area()
            {
                return width * height / 2;

            }
            public void  showstyle ()
            {
                MessageBox.Show(" trinagle is" + style, "trinagle style");

            }

        }
        class driver
        {
            static void main()
            {

             Application . EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                trinagle t1 = new trinagle();
                trinagle t2 = new trinagle();
                t1.width = 4.0;
                t1.height = 4.0;
                t1.style = " isosceles";
                t2.width = 8.0;
                t2.height = 12.0;
                t2.style="right";
                Form form = new Form();
                Button button = new Button();
                button.Text = " show trinagle info";
                button.Click+= (sender,e)=>
                {
                    MessageBox.Show(" info for t1 :", " trinagle information");
                    t1.showstyle();
                    t1.showdim();
                    MessageBox.Show(" area is" + t1.Area(), "area");


                    MessageBox.Show(" info for t2:", " trinagle information");
                    t2.showstyle();
                    t2.showdim();
                    MessageBox.Show(" area is" + t2.Area(), "area");






                }










                









        }







        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
