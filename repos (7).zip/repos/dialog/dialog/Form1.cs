﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dialog
{
    public partial class Form1 : Form
    {
        string textfile = "BMIS.txt";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using(StreamReader reader=new StreamReader(textfile))
            {
                //var filecontent=reader.ReadToEnd();
                //messagebox.show(filecontent);
                string line;
                while((line=reader.ReadLine())!=null)
                {
                    line = line.Trim();
                    MessageBox.Show(line);
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (StreamWriter writer = File.AppendText(textfile))
            {
                writer.Write(textBox1.Text + Environment.NewLine);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "choose a file for reading";
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.Filter = "txt files(*.txt)|*txt|all files(*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.ShowDialog();
            if(openFileDialog1.ShowDialog()== DialogResult.OK)
            {
                var filepath = openFileDialog1.FileName;
                var filestream = openFileDialog1.OpenFile();
                using (StreamReader reader= new StreamReader (filestream))
                {
                    var filecontent = reader.ReadToEnd();
                    textBox1.Text = (filecontent);
                    MessageBox.Show(filecontent);

                }
            }    
;        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
