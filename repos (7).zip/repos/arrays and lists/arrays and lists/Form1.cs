﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arrays_and_lists
{
    public partial class Form1 : Form
    {
        string[] texts = new string[3];
        double[] nums = new double[3];


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double sum = 0;
            nums[0] = double.Parse(textBox1.Text);
            nums[1] = double.Parse(textBox2.Text);
            nums[2] = double.Parse(textBox3.Text);
            for (int i = 0; i < nums.Length; i++)
            {
                sum += nums[i];
                textBox4.Text = sum.ToString();
                if (sum > 2000)
                {
                    textBox4.ForeColor = Color.DarkViolet;
                }

                else
                {

                    {
                        // reset the color to the default color if the sum is not over 2000
                        textBox4.ForeColor = SystemColors.ControlText;
                    }

                }

            }

        }

                }
        }
    
