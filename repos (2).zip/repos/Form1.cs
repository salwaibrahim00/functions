﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace project_programming
{
    public partial class Form1 : Form
    {
        string textfile = "BMIS.txt";
        public Form1()
        {
            InitializeComponent();
        }
        private double RoundedNumber(double numberToRound)

        {
            return Math.Round(numberToRound, 2);
        }




        private void button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out double numberToRound))
            {
                double roundedvalue = RoundedNumber(numberToRound);
                textBox1.Text = roundedvalue.ToString("0.00");//display with 2 decimal places
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (double.TryParse(textBox2.Text, out double pounds))

                for (int i = 1; i <= 5; i++)
                {
                    double kilograms = pounds * 0.45359237;
                    MessageBox.Show($"i={i}pounds= {pounds},kilograms={kilograms:F2}", "answer");

                }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            {
                using (StreamReader reader = new StreamReader(textfile))
                {

                    string line = reader.ReadLine();

                    while ((line = reader.ReadLine()) != null)
                    {
                        line = line.Trim();
                        MessageBox.Show(line);
                    }
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            using (StreamWriter writer = File.AppendText(textfile))
            {
                writer.Write(textBox3.Text + Environment.NewLine);
                // close the steamwriter here to ensure proper disposal
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Title = "choose a file for reading";
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files(*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.ShowDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var filepath = openFileDialog1.FileName;

                using (StreamReader reader = new StreamReader(filepath))
                {
                    var filecontent = reader.ReadToEnd();
                    textBox1.Text = (filecontent);
                    MessageBox.Show(filecontent, "file content");
                }
            }
        }
    }
}